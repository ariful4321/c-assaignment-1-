﻿using system;
namespace bank
{
    class Bank
private string bankName;
    private Account[] accounts;
    pub1ic Bank(string bankName, int size)
    {
        this.bankName = bankName;
        this.accounts = new Account[size];
    }
    public void Addaccount(Account account)
    {
        for (int i = 0; i < accounts.Length; i++)
        {
            if (accounts[i]) == null)
{
            accounts[i] = account;
            break;
        }
    }
}
public void DeleteAccount(Account account)
{
    for (int i = 0; i < account.Length; i++)
    {
        if accounts[i] == account
        {
            account[i] = null;
            break;
        }
    }
}


public void ShowDetails(int accountNo)
{
    for (int i = 0; i < account.Length; i++)
    {
        if (accounts[i].accountNumber == accountNO)
        {
            account[i].showAccount();
            break;
        }
    }
}
}
