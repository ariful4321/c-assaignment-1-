﻿using System;
namespace Account
{​​​ 
class Account
	{​​​ 
	
	public double currentBalance = 0.0
	public int accountNumber;
		public string accountName;
		public string address;
		//public string  mobileNumber;


		public string Accountname
		{​​​
 	set {​​​ this.accountName = value; }​​​
	get {​​​return this.accountName; }​​​
	}​​​
	
	public string Address
		{​​​
 	set {​​​ this.address = value; }​​​
	get {​​​return this.address; }​​​
	}​​​
	
	//public string MobileNumber
	//{​​​
 	//set {​​​ this.mobilenumber = value;}​​​
	//get {​​​return this.mobileNumber;}​​​
	//}​​​

	public string Accountnumber
		{​​​
 	set {​​​ this.accountNumber = value; }​​​
	get {​​​return this.accountNumber; }​​​
	}​​​


	public void Deposit(double amount)
		{​​​
currentBalance = currentBalance + amount;
			console.WriteLine("Balnce:" + currentBalance);
		}​​​
//1 reference
public void Withdraw(double anount)
(
if (amount != 0 && anount >= 10000 && currentBalance >=amount)
{​​​
currentBalance =currentBalance - amount;
Console.WriteLine("You raised money: " + amount);
console.WriteLine("your current balance is: " + currentBalance);
)
else
(
Console.WriteLine("The Balance is insufficient! !");
}​​​
}​​​
public void transfer(int accountReceiver, double money)
{​​​
if (accountReceiver == AccountNumber)
	{​​​
currentBalance = currentBalance - money;
		console.WriteLine(”You have transferred money: “ +money);
		console.WriteLine(”Your current balance is: +currentBalance);
}​​​
else
{​​​
Console.WriteLine(”Invalid account nunber!! “);
}​​​
}​​​


//o references
static void Main(string[] args)
{​​​
Account a5 = new AccountO;
	a5.accountName = “ariful islam";
a5.AccountNumber = 128403847374;
	a5.address = “North kafrul";
//a5.mobileNumber = “01788888889”;
	do
	{​​​
Console.WriteLine("1.Account infotn 2.Deposit money\n 3.Withdraw money\n 4.Transfer money");
		console.WriteLine(”Enter your choice: ");
		int  input = System.convert.ToInt32(Systen.console.ReadLineO));
		if (input != 0)
		{​​​
if (input = 1)
			{​​​
Conso].e.WriteLine(”Account INFO");=
Console.WriteLine(”Account Number: " + a5.AccountNumber);
Console.WriteLine(”Account Holder Name: " + a5.AccountName);
Console.WriteLine(”Account Holder Address: " + a5.Address);
//console.WriteLine(”Account Holder Mobile Nunber:"  + a5.MobileNunber);
console.WriteLine(”Balance: "  + a5.currentBalance);
}​​​


if (input = 2)
			{​​​
console: WriteLine(”Deposit section”);
				console.WriteLine("Enter the anount you wi11 deposit:");
				double anount = System.Convert.ToDouble(Systen.Console.ReadLine());
				a5.Deposit(amount);
			}​​​
if (input = 3)
			{​​​
Console.WriteLine("Withdraw section");.
console.WriteLine("Enter the amount you wi11 withdraw :");
				double amount = Systen.convert.ToDouble(Systen.console.ReadLine());
				a5.Withdraw(amount);
			}​​​
if (input = 4)
			{​​​
Console.WriteLine("Transfer section");.
console.WriteLine("Enter the amount you wi11 Transfer :");
				double amount = Systen.convert.ToDouble(Systen.console.ReadLine());
				a5.Transfer(accountReceiver, money);

			}​​​
}​​​
else
		{​​​
break;
		}​​​
}​​​while (1 != 0) ;
}​​​
}​​​
}​​​
